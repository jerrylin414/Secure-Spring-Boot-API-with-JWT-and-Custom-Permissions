package com.lzy.jshow.serivce;

public interface SysRoleService {
}
