package com.lzy.jshow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JshowApplication {

    public static void main(String[] args) {
        SpringApplication.run(JshowApplication.class, args);
    }

}
