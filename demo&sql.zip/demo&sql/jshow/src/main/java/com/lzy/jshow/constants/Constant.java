package com.lzy.jshow.constants;

public class Constant {
    public static final String IS_CHECKED = "Y";
    public static final String NO_CHECKED = "N";
    public static final String NULL_STR = null;
    public static final String NULL_STR_VAL = "";
    public static final String DESC = "desc";
    public static final String ASC = "asc";
    public static final String SYSTEM = "SYSTEM";
}
