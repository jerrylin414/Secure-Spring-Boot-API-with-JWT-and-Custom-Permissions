package com.lzy.jshow.serivce.impl;

import com.lzy.jshow.serivce.SysRoleService;
import org.springframework.stereotype.Service;

@Service
public class SysRoleServiceImpl implements SysRoleService {
}
